let currentScene;
let currentRoom;


function ResetGame() {
}