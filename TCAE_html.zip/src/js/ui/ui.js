let ui;

class UI extends BaseMenuScene {
    constructor() {
        super('ui');

        this.playing = false;
        this.pause = false;

        this.mobile = mobileAndTabletCheck();
    }

    create() {
        this.input.addPointer(3);
        ui = this;
        this.camera = this.cameras.main;

        this.text = this.add.text(240, 250, " ", {
            fontFamily: 'BetterPixelsAcce',
            fontSize: '32px',
            color: '#eeeeba',
            align: 'center'
        }).setDepth(10).setOrigin(.5, .5).setScrollFactor(0).setLineSpacing(4).setResolution(3);

        /*this.fullscreen = this.add.sprite(10, 244, 'fullscreen').setOrigin(0).setDepth(9).setInteractive().setVisible(true);
        this.fullscreen.on('pointerdown', function (event) {
            if (this.scale.isFullscreen) {
                this.scale.stopFullscreen();
            }
            else {
                this.scale.startFullscreen();
            }
        }, this);

        if (this.mobile) {
        }*/
    }

    update() {
        if (this.mobile) {

        }
        if (this.text.active) {

        }
    }

    EnableGameUI() { }

    HideGameUI() { }

    EnableMenuUI() { }

    ShowSelectedItem(name) {
        this.text.text = name;
    }

    ShowPatientInfo(patient) {
        if (currentScene.pause) { return; }

        currentScene.pause = true;

        this.background = this.add.rectangle(240, 135, 350, 180, 0x5599ff).setDepth(10).setScrollFactor(0).setOrigin(0.5);

        this.close = this.add.sprite(400, 62, 'close').setDepth(12).setScrollFactor(0).setInteractive().on('pointerdown', function (pointer, localX, localY, event) {
            ui.HidePatientInfo();
        });

        this.illness = this.add.text(300, 160, patient.illness, {
            fontFamily: 'm3x6',
            fontSize: '32px',
            color: '#eeeeba',
            align: 'center'
        }).setDepth(10).setOrigin(.5, .5).setScrollFactor(0).setLineSpacing(4);
    }

    HidePatientInfo() {
        currentScene.pause = false;
        this.background.destroy();
        this.close.destroy();
        this.illness.destroy();
    }

    ShowEnd(mistakes) {
        this.text.text = " ";
        this.background = this.add.rectangle(240, 135, 400, 220, 0x5599ff).setDepth(10).setScrollFactor(0).setOrigin(0.5);
        this.close = this.add.sprite(400, 62, 'close').setDepth(12).setScrollFactor(0).setInteractive().on('pointerdown', function (pointer, localX, localY, event) {
            currentScene.LoadScene("mainMenu");
        });

        for (let i = 0; i < mistakes.length; i++) {
            let m = mistakes[i];
            /*if (m["val"] > 0) {
                fail = true;
            }*/

            this.add.text(70, 30 + (20 * i), m["mistake"], {
                fontFamily: 'BetterPixelsAcce',
                fontSize: '16px',
                color: '#eeeeba',
                align: 'center'
            }).setDepth(15).setOrigin(0, 0).setScrollFactor(0).setResolution(3);
        }
    }

    ShowClothes() {
        if (currentScene.pause) { return; }
        currentScene.pause = true;

        this.background = this.add.rectangle(240, 135, 350, 180, 0xff6699).setDepth(10).setScrollFactor(0).setOrigin(0.5);

        this.close = this.add.sprite(400, 62, 'close').setDepth(12).setScrollFactor(0).setInteractive().on('pointerdown', function (pointer, localX, localY, event) {
            ui.HideClothes();
        });

        this.clothes = [];
        let guantes = this.add.sprite(100, 100, 'Guantes').setDepth(11).setScrollFactor(0).setScale(8).setInteractive().on('pointerdown', function (pointer, localX, localY, event) {
            if (currentScene.player.PutOn(ID_GUANTES))
                guantes.destroy();
        });
        this.clothes.push(guantes);

        let gorro = this.add.sprite(140, 100, 'Gorro').setDepth(11).setScrollFactor(0).setScale(8).setInteractive().on('pointerdown', function (pointer, localX, localY, event) {
            if (currentScene.player.PutOn(ID_GORRO))
                gorro.destroy();
        });
        this.clothes.push(gorro);

        let mascarilla = this.add.sprite(200, 100, 'Mascarilla').setDepth(11).setScrollFactor(0).setScale(8).setInteractive().on('pointerdown', function (pointer, localX, localY, event) {
            if (currentScene.player.PutOn(ID_MASCARILLA))
                mascarilla.destroy();
        });
        this.clothes.push(mascarilla);

        let gafas = this.add.sprite(300, 100, 'Gafas').setDepth(11).setScrollFactor(0).setScale(8).setInteractive().on('pointerdown', function (pointer, localX, localY, event) {
            if (currentScene.player.PutOn(ID_GAFAS))
                gafas.destroy();
        });
        this.clothes.push(gafas);

        let calzas = this.add.sprite(140, 200, 'Calzas').setDepth(11).setScrollFactor(0).setScale(8).setInteractive().on('pointerdown', function (pointer, localX, localY, event) {
            if (currentScene.player.PutOn(ID_CALZAS))
                calzas.destroy();
        });
        this.clothes.push(calzas);

        let bata = this.add.sprite(300, 200, 'Bata').setDepth(11).setScrollFactor(0).setScale(8).setInteractive().on('pointerdown', function (pointer, localX, localY, event) {
            if (currentScene.player.PutOn(ID_BATA))
                bata.destroy();
        });
        this.clothes.push(bata);

        for (let index = 0; index < this.clothes.length; index++) {
            this.clothes[index].on('pointerover', function (pointer) {
                ui.ShowSelectedItem(ui.clothes[index].texture.key);
            })

            this.clothes[index].on('pointerout', function (pointer) {
                ui.ShowSelectedItem(" ");
            })
        }
    }

    HideClothes() {
        currentScene.pause = false;
        for (let i = 0; i < this.clothes.length; i++) {
            this.clothes[i].destroy();
        }

        this.background.destroy();
        this.close.destroy();
    }

    ShowSink() {
        if (currentScene.pause) { return; }
        currentScene.pause = true;

        this.background = this.add.rectangle(240, 135, 350, 180, 0x5599ff).setDepth(10).setScrollFactor(0).setOrigin(0.5);

        this.soap = this.add.rectangle(64, 135, 64, 64, 0xff6699).setDepth(10).setScrollFactor(0).setOrigin(0).setInteractive().on('pointerdown', function (pointer, localX, localY, event) {
            currentScene.gameManager.WashHands(false, currentScene.player.WearsAnyClothes());
            ui.HideSink();
            currentScene.CheckMistakes();
        });
        //ShowNameOnHover(this.soap);

        this.soap2 = this.add.rectangle(200, 135, 64, 64, 0x2277ee).setDepth(10).setScrollFactor(0).setOrigin(0).setInteractive().on('pointerdown', function (pointer, localX, localY, event) {
            currentScene.gameManager.WashHands(true, currentScene.player.WearsAnyClothes());
            ui.HideSink();
            currentScene.CheckMistakes();
        });
        //ShowNameOnHover(this.soap2);

        this.close = this.add.sprite(400, 62, 'close').setDepth(12).setScrollFactor(0).setInteractive().on('pointerdown', function (pointer, localX, localY, event) {
            ui.HideSink();
        });
    }

    HideSink() {
        currentScene.pause = false;
        this.soap.destroy();
        this.soap2.destroy();
        this.background.destroy();
        this.close.destroy();
    }

    ShowActions() {
        if (currentScene.pause || currentRoom.patient.takenCareOf) { return; }

        currentScene.pause = true;

        this.background = this.add.rectangle(240, 135, 350, 180, 0x5599ff).setDepth(10).setScrollFactor(0).setOrigin(0.5);

        this.close = this.add.sprite(400, 62, 'close').setDepth(12).setScrollFactor(0).setInteractive().on('pointerdown', function (pointer, localX, localY, event) {
            ui.HideActions();
        });

        this.buttons = [];

        let a = this.add.text(300, 160, "aaaaaaaa", {
            fontFamily: 'm3x6',
            fontSize: '32px',
            color: '#eeeeba',
            align: 'center'
        }).setDepth(10).setOrigin(.5, .5).setScrollFactor(0).setLineSpacing(4);

        a.setInteractive().on('pointerdown', function (event) {
            currentScene.player.CarryTrash(currentRoom.patient.illnessType);
            currentScene.actionsDone++;
            currentRoom.patient.takenCareOf = true;
            ui.HideActions();
        }, this);

        this.buttons.push(a);
    }

    HideActions() {
        currentScene.pause = false;
        for (let i = 0; i < this.buttons.length; i++) {
            this.buttons[i].destroy();
        }
        this.background.destroy();
        this.close.destroy();
    }

    ShowRoomManager() {
        this.items = [];
        currentScene.pause = true;

        this.background = this.add.rectangle(240, 135, 480, 270, 0x5599ff).setDepth(10).setScrollFactor(0).setOrigin(0.5);
        this.ok = this.add.text(240, 250, "OK", {
            fontFamily: 'BetterPixelsAcce',
            fontSize: '32px',
            color: '#eeeeba',
            align: 'left'
        }).setDepth(10).setOrigin(0.5, 0.5).setScrollFactor(0).setLineSpacing(4).setResolution(3).setInteractive().on('pointerdown', function (pointer, localX, localY, event) {
            ui.HideRoomManager();
        });


        //this.add.sprite(240, 250, 'close').setDepth(12).setScrollFactor(0)

        this.pressures = [0, 0, 0, 0];
        this.roomTypes = [0, 0, 0, 0];

        for (let i = 0; i < currentScene.rooms.length; i++) {
            let x = (200 * (i % 2));
            let y = (100 * Math.floor(i / 2));

            let patient = currentScene.rooms[i].patient;
            let patientSprite = this.add.sprite(80 + x, 70 + y, "pacientes").setDepth(12).setScrollFactor(0).setScale(2).setFrame(patient.frame.name);
            patientSprite.angle = 90;
            let patientText = this.add.text(100 + x, 70 + y, patient.illness, {
                fontFamily: 'BetterPixelsAcce',
                fontSize: '16px',
                color: '#eeeeba',
                align: 'left'
            }).setDepth(10).setOrigin(0, 0.5).setScrollFactor(0).setLineSpacing(4).setResolution(3);

            let pressureButton = this.add.rectangle(80 + x, 90 + y, 32, 32, 0x777777).setDepth(10).setScrollFactor(0).setOrigin(0).setInteractive().on('pointerdown', function () {

                switch (this.pressure) {
                    case NO_PRESSURE:
                        this.pressure = POS_PRESSURE;
                        this.setFillStyle(0xff6699, 1);
                        break;
                    case POS_PRESSURE:
                        this.pressure = NEG_PRESSURE;
                        this.setFillStyle(0xaaccff, 1);
                        break;
                    case NEG_PRESSURE:
                        this.pressure = NO_PRESSURE;
                        this.setFillStyle(0x777777, 1);
                        break;
                    default:
                        break;
                }

                ui.pressures[this.id] = this.pressure;
            });

            pressureButton.id = i;
            pressureButton.pressure = NO_PRESSURE;

            let roomTypeButton = this.add.rectangle(120 + x, 90 + y, 32, 32, 0x777777).setDepth(10).setScrollFactor(0).setOrigin(0).setInteractive().on('pointerdown', function () {
                this.roomType = !this.roomType;
                if (this.roomType) {
                    this.setFillStyle(0xccffcc, 1);
                } else {
                    this.setFillStyle(0x777777, 1);
                }

                ui.roomTypes[this.id] = this.roomType;
            });
            roomTypeButton.id = i;
            roomTypeButton.roomType = false;

            this.items.push(patientSprite);
            this.items.push(patientText);
            this.items.push(pressureButton);
            this.items.push(roomTypeButton);
        }
    }

    HideRoomManager() {
        currentScene.pause = false;
        for (let i = 0; i < this.items.length; i++) {
            this.items[i].destroy();
        }
        this.background.destroy();
        this.ok.destroy();

        currentScene.gameManager.CheckRoomMistakes(this.pressures, this.roomTypes);
        currentScene.CheckMistakes();
    }
}

//https://stackoverflow.com/questions/11381673/detecting-a-mobile-browser
window.mobileAndTabletCheck = function () {
    let check = false;
    (function (a) { if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4))) check = true; })(navigator.userAgent || navigator.vendor || window.opera);
    return check;
};

